package com.example.runrun

import android.os.Bundle
import android.os.PersistableBundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import org.xmlpull.v1.XmlPullParserException
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class NetworkActivity : AppCompatActivity() {
    private var startOrStop: String? = intent.getStringExtra("startOrStop")
    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState)
        if (startOrStop == "start"){
            loadPage()
        }
    }

    companion object {

        const val WIFI = "Wi-Fi"
        const val ANY = "Any"
        const val BUS_URL =
            "http://ws.bus.go.kr/api/rest/arrive/getArrInfoByRoute?ServiceKey=eR654WhVA2%2FiRXBlwnzEwvgRkDdAXPLHMwmIm3zmnYRZADkNhoWqA6lNj8QWyUWVyLLBXrrxJ6CkJ0h%2B4lCvyQ%3D%3D&stId=109000052&busRouteId=109900010&ord=26"

        // Whether there is a Wi-Fi connection.
        private var wifiConnected = true //true로 바꿔둠

        // Whether there is a mobile connection.
        private var mobileConnected = false

        // Whether the display should be refreshed.
        //var refreshDisplay = true

        // The user's current network preference setting.
        var sPref: String? = ANY //ANY로 바꿔둠
    }

    // Asynchronously downloads the XML feed from BUS API.
    // XML피드의 URL을 포함한 문자열 변수를 초기화합니다.
    // 사용자의 설정과 네트워크 연결에서 허용하는 경우 downloadXml(url) 메서드를 호출합니다.
    // 이 메서드는 피드를 다운로드하여 파싱하고 UI에 표시될 문자열 결과를 반환합니다.
    private fun loadPage() {
        if (sPref.equals(ANY) && (wifiConnected || mobileConnected)) {
            downloadXml(BUS_URL)
        } else if (sPref.equals(WIFI) && wifiConnected) {
            downloadXml(BUS_URL)
        } else {
            // Show error. 에러 시 사용자에게 무엇을 보여줄 것인가?
        }
    }

    // Download XML feed from BUS API.
    // vararg는 가변인자이다.
    private fun downloadXml(vararg urls: String) {
        var result: String?
        //피드 URL을 매개변수로 전달
        //loadXmlFromNetwork() 메서드가 피드를 가져와서 처리
        //작업이 완료되면 결과 문자열을 다시 전달
        result = try {
            // loadXmlFromNetwork()의 반환값은 HTML string
            loadXmlFromNetwork(urls[0]) // 여기서 왜 urls[0]인지 모르겠다!!!
        } catch (e: IOException) {
            resources.getString(R.string.connection_error)
        } catch (e: XmlPullParserException) {
            resources.getString(R.string.xml_error)
        }
        setContentView(R.layout.activity_main)
        // Displays the HTML string in the UI via a WebView.
        findViewById<WebView>(R.id.xml_webview)?.apply {
            //Loads the given data into this WebView using a 'data' scheme URL.
            loadData(result ?: "", "text/html", null)
        }
    }

    // Uploads XML from 버스 링크, parses it, and combines it with HTML markup. Returns HTML string.
    @Throws(XmlPullParserException::class, IOException::class)
    private fun loadXmlFromNetwork(urlString: String): String {
        //함수를 람다로 변수entries에 넣는 방식이다
        //.use함수는 Executes the given block function on this resource and then closes it down correctly whether an exception is thrown or not
        //downloadUrl(urlString)?의 Inputstream타입의 리턴값을 stream이라는 이름의 매개변수로 넣어서 람다 실행
        //이 람다의 리턴값의 타입은 emptyList이다??? 이건 잘 모르겠음
        val entries: List<BusRouteListXmlParser.ItemList> = downloadUrl(urlString)?.use { stream ->
            // Instantiates the parser.
            //내가 만든 parse()에 넣는다. parse()는 List<ItemList>를 반환함
            BusRouteListXmlParser().parse(stream)
            //emptyList()는 Returns an empty read-only list. The returned list is serializable (JVM).
            //null이라면 emptyList()를 반환하라는 건가? 이 부분은 잘 모르겠다.
        } ?: emptyList()
        //String은 문자열을 수정했을 때 수정된 문자열을 새로 생성 후 참조를 바꾼다. (비효율적임)
        //하지만 StringBuilder()는 문자열을 수정하는 작업을 할 때 기존의 참조를 바꾸는게 아니라 참조하고 있는 값을 바꾼다
        //.apply는 Calls the specified function block with this value as its receiver and returns this value.
        return StringBuilder().apply {
            // StringBuilder(A mutable sequence of characters)를 리턴하는 건지 toString()으로 String을 리턴하는 건지 모르겠다ㅡ!!!!!
            append("<h3>${resources.getString(R.string.page_title)}</h3>")//append()의 매개변수는 String이고 리턴값은 StringBuilder이다.
            append("<em>${resources.getString(R.string.updated)}</em>")
            // BusRouteListXmlParser returns a List (called "entries") of ItemList objects. (위에 선언함)
            // Each ItemList object represents a single post in the XML feed.
            // This section processes the entries list to combine each entry with HTML markup.
            // Each entry is displayed in the UI as a link that optionally includes a text summary.
            //.forEach는 Performs the given action on each element.
            entries.forEach { entry ->
                append("<p>" + entry.rtNm + "</p><br>")
                append("<p>" + entry.stNm + "</p><br>")
                append("<p>" + entry.arrmsg1 + "</p><br>")
                append("<p>" + entry.arrmsg2 + "</p><br>")
            } //entries에서 하나씩 가져와서 HTML이랑 합치기
        }.toString() //toString()은 Returns a string representation of the object.
    }

    // Given a string representation of a URL, sets up a connection and gets an input stream.
    @Throws(IOException::class)
    //downloadUrl(버스 링크) : 리턴값은 InputStream? 타입이다.
    private fun downloadUrl(urlString: String): InputStream? {
        //URL()함수는 creates a URL object from the String representation
        //즉, 버스 링크의 URL객체를 만들어준다
        val url = URL(urlString)
        //openConnection()함수는 Returns a URLConnection instance that represents a connection to the remote object referred to by the URL
        //여기서 as? 연산자는 어떤 값을 HttpURLConnection 타입으로 캐스트를 하고, 만약 캐스트 할 수 없으면 null을 반환하게 됩니다.
        //.run은 The context object is available as a receiver (this: HttpURLConnection)이다.
        //lambda result를 리턴한다
        //run is useful when your lambda both initializes objects & computes the return value.
        return (url.openConnection() as? HttpURLConnection)?.run {
            // Sets the read timeout to a specified timeout, in milliseconds.
            // A non-zero value specifies the timeout when reading from Input stream when a connection is established to a resource.
            readTimeout = 10000
            //Sets a specified timeout value, in milliseconds, to be used when opening a communications link to the resource referenced by this URLConnection.
            // If the timeout expires before the connection can be established, a java.net.SocketTimeoutException is raised.
            connectTimeout = 15000
            requestMethod = "GET"
            doInput = true
            // Starts the query.
            //connect() 함수는 Opens a communications link to the resource referenced by this URL,
            // if such a connection has not already been established.
            connect()
            //Returns an input stream that reads from this open connection
            inputStream
        }
    }

}